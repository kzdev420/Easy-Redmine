class AddIndexOnMemberRolesInheritedFrom < ActiveRecord::Migration[4.2]
end
