class ChangeTimeEntriesCommentsLimitTo1024 < ActiveRecord::Migration[4.2]
end
